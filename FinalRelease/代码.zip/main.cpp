#include <iostream>
#include "src/Application.hpp"

int main(int argc, char *argv[]) {
	Application App;
	App.Run();

	return 0;
}
