//
// Created by adamyuan on 1/1/18.
//
#include "Util.hpp"

AABB::AABB(const glm::vec3 &_min, const glm::vec3 &_max) : min_(_min), max_(_max)
{

}


